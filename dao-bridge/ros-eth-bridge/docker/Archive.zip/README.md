## Build
docker build -t ros-eth:noetic .

## run
docker run --rm -it --name ros_eth_gateway --network host -e ROS_MASTER_URI=http://127.0.0.1:11311 -e ROS_IP=127.0.0.1 -e ETH_WALLET_PASSPHRASE='' -v "/home/laude/repos/ROS-DLT-interface/ROS-interface/docker/configs/dao.yaml":/root/catkin_ws/src/ros_eth_bridge/config/dao.yaml:ro -v "/home/laude/repos/ROS-DLT-interface/ROS-interface/docker/configs/wallet.json":/root/.ros_eth/wallet.json:ro ros-eth:noetic
