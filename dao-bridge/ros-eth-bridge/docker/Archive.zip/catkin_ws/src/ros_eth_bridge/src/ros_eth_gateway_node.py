#!/usr/bin/env python3
import os, sys
import rospy
import rospkg
from web3 import Web3

# import helpers from this package
pkg_path = rospkg.RosPack().get_path("ros_eth_bridge")
sys.path.insert(0, os.path.join(pkg_path, "src"))

from abi_loader import load_config, make_web3, load_contract

from ros_eth_msgs.msg import ServiceInfo, TaskInfo
from ros_eth_msgs.srv import (
    GetService, GetServiceResponse,
    GetAllServices, GetAllServicesResponse,
    GetServicesByCreator, GetServicesByCreatorResponse,
    GetTask, GetTaskResponse,
    GetAllTasks, GetAllTasksResponse,
    GetTasksByCreator, GetTasksByCreatorResponse,
)

class Gateway:
    def __init__(self):
        rospy.init_node("ros_eth_gateway")

        self.cfg = load_config()
        self.w3  = make_web3(self.cfg)

        c = self.cfg["contracts"]
        p = self.cfg["abi_paths"]
        self.serv = load_contract(self.w3, c["service_manager"], p["service_manager"])
        self.task = load_contract(self.w3, c["task_manager"],   p["task_manager"])

        # default creator for convenience, falls back to dao.yaml wallet
        self.default_creator = None
        try:
            self.default_creator = Web3.to_checksum_address(self.cfg["wallet"]["address"])
        except Exception:
            self.default_creator = None

        # expose services
        rospy.Service("/dao/get_service_by_id",             GetService,            self.srv_get_service)
        rospy.Service("/dao/get_all_services",        GetAllServices,        self.srv_get_all_services)
        rospy.Service("/dao/get_services_by_creator", GetServicesByCreator,  self.srv_get_services_by_creator)

        rospy.Service("/dao/get_task_by_id",                GetTask,               self.srv_get_task)
        rospy.Service("/dao/get_all_tasks",           GetAllTasks,           self.srv_get_all_tasks)
        rospy.Service("/dao/get_tasks_by_creator",    GetTasksByCreator,     self.srv_get_tasks_by_creator)

        rospy.loginfo("ros_eth_gateway ready, chain %s", self.w3.eth.chain_id)

    # pack helpers

    @staticmethod
    def _pack_service_tuple(s) -> ServiceInfo:
        # Service struct:
        # id, name, description, serviceCategory, serviceType, categoryHash, serviceTypeHash,
        # price, creator, active, providerType, busy
        msg = ServiceInfo()
        msg.id = int(s[0])
        msg.name = s[1]
        msg.description = s[2]
        msg.category = s[3]
        msg.service_type = s[4]
        msg.price_wei = str(s[7])
        msg.creator = str(s[8])
        msg.active = bool(s[9])
        msg.provider_type = int(s[10])
        msg.busy = bool(s[11])
        return msg

    @staticmethod
    def _pack_task_tuple(t) -> TaskInfo:
        # Task struct:
        # id, description, taskCategory, taskType, categoryHash, taskTypeHash,
        # creator, reward, status, executor, active, proofURI, oracle, verified
        msg = TaskInfo()
        msg.id = int(t[0])
        msg.description = t[1]
        msg.category = t[2]
        msg.task_type = t[3]
        msg.creator = str(t[6])
        msg.reward_wei = str(t[7])
        msg.status = int(t[8])
        msg.executor = str(t[9])
        msg.active = bool(t[10])
        msg.proof_uri = t[11]
        msg.verified = bool(t[13])
        return msg

    # services

    def srv_get_service(self, req):
        try:
            s = self.serv.functions.getService(int(req.service_id)).call()
            return GetServiceResponse(ok=True, service=self._pack_service_tuple(s))
        except Exception as e:
            rospy.logwarn("get_service %s failed: %s", req.service_id, str(e))
            return GetServiceResponse(ok=False, service=ServiceInfo())

    def srv_get_all_services(self, _req):
        try:
            items = self.serv.functions.getAllServices().call()
            out = [self._pack_service_tuple(s) for s in items]
            return GetAllServicesResponse(ok=True, services=out)
        except Exception as e:
            rospy.logwarn("get_all_services failed, trying count loop: %s", str(e))
            try:
                n = int(self.serv.functions.getServiceCount().call())
                out = []
                for i in range(1, n + 1):
                    out.append(self._pack_service_tuple(self.serv.functions.getService(i).call()))
                return GetAllServicesResponse(ok=True, services=out)
            except Exception as e2:
                rospy.logwarn("fallback get_all_services failed: %s", str(e2))
                return GetAllServicesResponse(ok=False, services=[])

    def srv_get_services_by_creator(self, req):
        try:
            creator = req.creator.strip()
            if not creator:
                if not self.default_creator:
                    raise RuntimeError("creator not provided and wallet.address missing in dao.yaml")
                creator = self.default_creator
            creator = Web3.to_checksum_address(creator)
            ids = self.serv.functions.getServicesByCreator(creator).call()
            out = [self._pack_service_tuple(self.serv.functions.getService(int(sid)).call()) for sid in ids]
            return GetServicesByCreatorResponse(ok=True, services=out)
        except Exception as e:
            rospy.logwarn("get_services_by_creator failed: %s", str(e))
            return GetServicesByCreatorResponse(ok=False, services=[])

    def srv_get_task(self, req):
        try:
            t = self.task.functions.getTask(int(req.task_id)).call()
            return GetTaskResponse(ok=True, task=self._pack_task_tuple(t))
        except Exception as e:
            rospy.logwarn("get_task %s failed: %s", req.task_id, str(e))
            return GetTaskResponse(ok=False, task=TaskInfo())

    def srv_get_all_tasks(self, _req):
        try:
            items = self.task.functions.getAllTasks().call()
            out = [self._pack_task_tuple(t) for t in items]
            return GetAllTasksResponse(ok=True, tasks=out)
        except Exception as e:
            rospy.logwarn("get_all_tasks failed, trying count loop: %s", str(e))
            try:
                n = int(self.task.functions.getTotalTasks().call())
                out = []
                for i in range(1, n + 1):
                    out.append(self._pack_task_tuple(self.task.functions.getTask(i).call()))
                return GetAllTasksResponse(ok=True, tasks=out)
            except Exception as e2:
                rospy.logwarn("fallback get_all_tasks failed: %s", str(e2))
                return GetAllTasksResponse(ok=False, tasks=[])

    def srv_get_tasks_by_creator(self, req):
        try:
            creator = req.creator.strip()
            if not creator:
                if not self.default_creator:
                    raise RuntimeError("creator not provided and wallet.address missing in dao.yaml")
                creator = self.default_creator
            creator = Web3.to_checksum_address(creator)
            ids = self.task.functions.getTasksByCreator(creator).call()
            out = [self._pack_task_tuple(self.task.functions.getTask(int(tid)).call()) for tid in ids]
            return GetTasksByCreatorResponse(ok=True, tasks=out)
        except Exception as e:
            rospy.logwarn("get_tasks_by_creator failed: %s", str(e))
            return GetTasksByCreatorResponse(ok=False, tasks=[])

def main():
    Gateway()
    rospy.spin()

if __name__ == "__main__":
    main()