#!/usr/bin/env python3
# Placeholder for mapping between ROS calls and contract calls
