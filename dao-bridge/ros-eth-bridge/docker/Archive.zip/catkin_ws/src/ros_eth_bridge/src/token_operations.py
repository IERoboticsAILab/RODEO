#!/usr/bin/env python3
import os, sys, time, getpass
import rospy, rospkg, actionlib
from web3 import Web3
from eth_account import Account

# import helpers from this package
pkg_path = rospkg.RosPack().get_path("ros_eth_bridge")
sys.path.insert(0, os.path.join(pkg_path, "src"))
from abi_loader import load_config, make_web3, load_contract

# services
from ros_eth_msgs.srv import GetBalance, GetBalanceResponse
from ros_eth_msgs.srv import GetAllowance, GetAllowanceResponse

# actions
from ros_eth_msgs.msg import TransferTokenAction, TransferTokenFeedback, TransferTokenResult
from ros_eth_msgs.msg import ApproveSpenderAction, ApproveSpenderFeedback, ApproveSpenderResult

class Wallet:
    def __init__(self, cfg):
        self.addr = Web3.to_checksum_address(cfg["wallet"]["address"])
        self.path = os.path.expanduser(cfg["wallet"]["keystore_path"])
        self._key = None

    def unlock(self):
        if self._key:
            return
        ks = open(self.path, "r").read()
        pw = None
        try:
            if rospy.has_param("~wallet_passphrase"):
                pw = rospy.get_param("~wallet_passphrase")
        except Exception:
            pass
        if pw is None and "ETH_WALLET_PASSPHRASE" in os.environ:
            pw = os.environ["ETH_WALLET_PASSPHRASE"]
        if pw is None:
            pw = ""
        self._key = Account.decrypt(ks, pw)

    @property
    def key(self):
        if not self._key:
            self.unlock()
        return self._key

class TokenOps:
    def __init__(self):
        rospy.init_node("token_operations")

        self.cfg = load_config()
        self.w3  = make_web3(self.cfg)
        self.wallet = Wallet(self.cfg)

        c = self.cfg["contracts"]
        p = self.cfg["abi_paths"]
        self.iec = load_contract(self.w3, c["iecoin"], p["iecoin"])

        tx_cfg = self.cfg.get("transaction", {}) or {}
        self.max_fee      = int(tx_cfg.get("max_fee_per_gas_wei", 0)) or None
        self.max_priority = int(tx_cfg.get("max_priority_fee_per_gas_wei", 0)) or None

        # services
        rospy.Service("/dao/get_balance",   GetBalance,   self.srv_get_balance)
        rospy.Service("/dao/get_allowance", GetAllowance, self.srv_get_allowance)

        # actions
        self.as_transfer = actionlib.SimpleActionServer(
            "/dao/transfer_token_action",
            TransferTokenAction,
            execute_cb=self.handle_transfer,
            auto_start=False,
        )
        self.as_approve = actionlib.SimpleActionServer(
            "/dao/approve_spender_action",
            ApproveSpenderAction,
            execute_cb=self.handle_approve,
            auto_start=False,
        )
        self.as_transfer.start()
        self.as_approve.start()

        rospy.loginfo("token_operations ready, chain %s, sender %s",
                      self.w3.eth.chain_id, self.wallet.addr)

    # common tx helpers

    def build_common_tx(self):
        sender = self.wallet.addr
        nonce  = self.w3.eth.get_transaction_count(sender)
        tx = {"from": sender, "nonce": nonce, "chainId": self.w3.eth.chain_id}
        if self.max_fee and self.max_priority:
            tx["maxFeePerGas"] = self.max_fee
            tx["maxPriorityFeePerGas"] = self.max_priority
            tx["type"] = 2
        return tx

    def sign_send_wait(self, tx, min_conf, publish_feedback, make_fb):
        signed = self.w3.eth.account.sign_transaction(tx, self.wallet.key)
        txh = self.w3.eth.send_raw_transaction(signed.raw_transaction)
        hexh = txh.hex()
        rospy.loginfo("tx %s sent, waiting for %d confirmations", hexh, max(1, min_conf))
        publish_feedback(make_fb(state="pending", tx_hash=hexh, confirmations=0, error=""))

        rcpt = self.w3.eth.wait_for_transaction_receipt(txh, timeout=600)
        block = rcpt.blockNumber
        ok = (rcpt.status == 1)
        if ok: rospy.loginfo("tx %s confirmed in block %d", hexh, block)
        else:  rospy.logwarn("tx %s failed in block %d", hexh, block)

        conf = 1
        while conf < max(1, min_conf) and not rospy.is_shutdown():
            latest = self.w3.eth.block_number
            conf = max(1, int(latest) - int(block) + 1)
            publish_feedback(make_fb(state="included", tx_hash=hexh, confirmations=conf, error=""))
            if conf >= min_conf:
                break
            time.sleep(1.0)
        return hexh, block, ok

    # services

    def srv_get_balance(self, req):
        try:
            owner = Web3.to_checksum_address(req.owner)
            bal = self.iec.functions.balanceOf(owner).call()
            dec = int(self.iec.functions.decimals().call())
            return GetBalanceResponse(ok=True, balance_wei=str(bal), decimals=dec)
        except Exception as e:
            rospy.logwarn("get_balance failed: %s", str(e))
            return GetBalanceResponse(ok=False, balance_wei="0", decimals=0)

    def srv_get_allowance(self, req):
        try:
            owner = Web3.to_checksum_address(req.owner)
            spender = Web3.to_checksum_address(req.spender)
            allo = self.iec.functions.allowance(owner, spender).call()
            return GetAllowanceResponse(ok=True, allowance_wei=str(allo))
        except Exception as e:
            rospy.logwarn("get_allowance failed: %s", str(e))
            return GetAllowanceResponse(ok=False, allowance_wei="0")

    # actions

    def handle_transfer(self, goal):
        pubfb = self.as_transfer.publish_feedback
        make_fb = lambda **k: TransferTokenFeedback(**k)
        try:
            self.wallet.unlock()

            to = Web3.to_checksum_address(goal.to.strip())
            if int(goal.amount) <= 0:
                raise ValueError("amount must be positive")
            amount_wei = self.w3.to_wei(int(goal.amount), "ether")  # IEC integer to wei

            fn = self.iec.functions.transfer(to, int(amount_wei))
            tx = self.build_common_tx()
            gas = fn.estimate_gas({"from": self.wallet.addr})
            tx["gas"] = int(gas * 1.2)
            tx = fn.build_transaction(tx)

            txh, block, ok = self.sign_send_wait(tx, max(1, int(goal.min_confirmations or 1)), pubfb, make_fb)
            res = TransferTokenResult(ok=bool(ok), tx_hash=txh, block_number=int(block))
            if ok: self.as_transfer.set_succeeded(res)
            else:  self.as_transfer.set_aborted(res, "tx reverted")
        except Exception as e:
            res = TransferTokenResult(ok=False, tx_hash="", block_number=0)
            self.as_transfer.set_aborted(res, str(e))

    def handle_approve(self, goal):
        pubfb = self.as_approve.publish_feedback
        make_fb = lambda **k: ApproveSpenderFeedback(**k)
        try:
            self.wallet.unlock()

            spender = Web3.to_checksum_address(goal.spender.strip())
            if int(goal.amount) < 0:
                raise ValueError("amount must be zero or positive")
            amount_wei = self.w3.to_wei(int(goal.amount), "ether")

            fn = self.iec.functions.approve(spender, int(amount_wei))
            tx = self.build_common_tx()
            gas = fn.estimate_gas({"from": self.wallet.addr})
            tx["gas"] = int(gas * 1.2)
            tx = fn.build_transaction(tx)

            txh, block, ok = self.sign_send_wait(tx, max(1, int(goal.min_confirmations or 1)), pubfb, make_fb)
            res = ApproveSpenderResult(ok=bool(ok), tx_hash=txh, block_number=int(block))
            if ok: self.as_approve.set_succeeded(res)
            else:  self.as_approve.set_aborted(res, "tx reverted")
        except Exception as e:
            res = ApproveSpenderResult(ok=False, tx_hash="", block_number=0)
            self.as_approve.set_aborted(res, str(e))

def main():
    TokenOps()
    rospy.spin()

if __name__ == "__main__":
    main()