#!/usr/bin/env python3
import os, sys
import json
import time
import threading
import rospy
import rospkg
from web3 import Web3
# Ensure we import helper modules from the package src folder
pkg_path = rospkg.RosPack().get_path("ros_eth_bridge")
sys.path.insert(0, os.path.join(pkg_path, "src"))

from abi_loader import load_config, make_web3, load_contract
import abi_loader as abi_mod

from ros_eth_msgs.msg import (
    TaskId,
    TaskAssignment,
    TaskRejection,
    ServiceMeta,
    ServiceBusy,
    TaskRegistered,
)

CHECKPOINT_FILE = os.path.expanduser("~/.ros_eth/event_checkpoint.json")

def get_logs_compat(event, from_block, to_block):
    # web3 v6 uses snake case, v5 uses camel case
    try:
        return event.get_logs(from_block=from_block, to_block=to_block)
    except TypeError:
        return event.get_logs(fromBlock=from_block, toBlock=to_block)

class Checkpoint:
    def __init__(self, path):
        self.path = path
        self.data = {
            "from_block": None,
            "last_log": {"block": 0, "index": -1}
        }
        self._load()

    def _load(self):
        try:
            with open(self.path, "r") as f:
                self.data = json.load(f)
        except Exception:
            pass

    def save(self):
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        tmp = self.path + ".tmp"
        with open(tmp, "w") as f:
            json.dump(self.data, f)
        os.replace(tmp, self.path)

    def next_from_block(self, latest):
        fb = self.data.get("from_block")
        if fb is None:
            # start from latest block to only get new events
            fb = latest
        return max(0, int(fb))

    def update_cursor(self, block, log_index):
        cur = self.data["last_log"]
        if block > cur["block"] or (block == cur["block"] and log_index > cur["index"]):
            cur["block"] = block
            cur["index"] = log_index
            self.data["from_block"] = block
    
    def last_cursor(self):
        cur = self.data.get("last_log", {"block": 0, "index": -1})
        return int(cur.get("block", 0)), int(cur.get("index", -1))

class EthEventListener:
    def __init__(self):
        rospy.init_node("eth_event_listener")
        self.cfg = load_config()
        self.w3 = make_web3(self.cfg)

        c = self.cfg["contracts"]
        p = self.cfg["abi_paths"]
        self.taskman = load_contract(self.w3, c["task_manager"], p["task_manager"])
        self.servman = load_contract(self.w3, c["service_manager"], p["service_manager"])

        # publishers
        self.pub_task_assigned = rospy.Publisher("/dao/task_assigned", TaskAssignment, queue_size=50)
        self.pub_task_unassigned = rospy.Publisher("/dao/task_unassigned", TaskId, queue_size=50)
        self.pub_task_verified = rospy.Publisher("/dao/task_verified", TaskId, queue_size=50)
        self.pub_task_rejected = rospy.Publisher("/dao/task_rejected", TaskRejection, queue_size=50)
        self.pub_service_registered = rospy.Publisher("/dao/service_registered", ServiceMeta, queue_size=50)
        self.pub_task_registered = rospy.Publisher("/dao/task_registered", TaskRegistered, queue_size=50)
        self.pub_service_busy = rospy.Publisher("/dao/service_busy", ServiceBusy, queue_size=50)

        self.ckpt = Checkpoint(CHECKPOINT_FILE)
        self.poll_interval = rospy.get_param("~poll_interval_sec", 1.0)
        self.chunk = rospy.get_param("~block_chunk", 1000)

        self.thread = threading.Thread(target=self.loop, daemon=True)
        self.thread.start()

    def _is_new_log(self, ev):
        last_block, last_index = self.ckpt.last_cursor()
        b = int(ev["blockNumber"])
        i = int(ev["logIndex"])
        return (b > last_block) or (b == last_block and i > last_index)

    def _iter_fresh(self, event_obj, from_block, to_block):
        logs = get_logs_compat(event_obj, from_block, to_block)
        # ensure deterministic order by block then index
        logs = sorted(logs, key=lambda e: (int(e["blockNumber"]), int(e["logIndex"])))
        for ev in logs:
            if self._is_new_log(ev):
                yield ev

    def loop(self):
        rate = rospy.Rate(1.0 / self.poll_interval if self.poll_interval > 0 else 1.0)
        while not rospy.is_shutdown():
            try:
                self.process_all()
            except Exception as e:
                rospy.logwarn("event listener error: %s", repr(e))
            rate.sleep()

    def process_all(self):
        latest = self.w3.eth.block_number
        start = self.ckpt.next_from_block(latest)
        end = latest
        if start > end:
            return

        # process in chunks
        cursor = start
        while cursor <= end and not rospy.is_shutdown():
            upper = min(cursor + self.chunk, end)
            self.process_range(cursor, upper)
            cursor = upper + 1
            self.ckpt.save()

    def process_range(self, from_block, to_block):
        # TaskRegistered
        for ev in self._iter_fresh(self.taskman.events.TaskRegistered(), from_block, to_block):
            tid = int(ev["args"]["taskId"])
            creator = str(ev["args"]["creator"])
            blk = int(ev["blockNumber"])
            self.pub_task_registered.publish(TaskRegistered(
                task_id=tid,
                creator=creator,
                block_number=blk,
            ))
            self._bump_cursor(ev)
        
        # TaskAssigned
        for ev in self._iter_fresh(self.taskman.events.TaskAssigned(), from_block, to_block):
            self.handle_task_assigned(ev)
            self._bump_cursor(ev)

        # TaskUnassigned
        for ev in self._iter_fresh(self.taskman.events.TaskUnassigned(), from_block, to_block):
            tid = int(ev["args"]["taskId"])
            self.pub_task_unassigned.publish(TaskId(task_id=tid))
            self._bump_cursor(ev)

        # TaskVerified
        for ev in self._iter_fresh(self.taskman.events.TaskVerified(), from_block, to_block):
            tid = int(ev["args"]["taskId"])
            self.pub_task_verified.publish(TaskId(task_id=tid))
            self._bump_cursor(ev)

        # TaskRejected
        for ev in self._iter_fresh(self.taskman.events.TaskRejected(), from_block, to_block):
            tid = int(ev["args"]["taskId"])
            reason = ev["args"].get("reason", "")
            self.pub_task_rejected.publish(TaskRejection(task_id=tid, reason=reason))
            self._bump_cursor(ev)

        # ServiceRegistered
        for ev in self._iter_fresh(self.servman.events.ServiceRegistered(), from_block, to_block):
            sid = int(ev["args"]["serviceId"])
            self.handle_service_registered(sid)
            self._bump_cursor(ev)

        # ServiceBusyUpdated
        for ev in self._iter_fresh(self.servman.events.ServiceBusyUpdated(), from_block, to_block):
            sid = int(ev["args"]["serviceId"])
            busy = bool(ev["args"]["busy"])
            self.pub_service_busy.publish(ServiceBusy(service_id=sid, busy=busy))
            self._bump_cursor(ev)

    def handle_task_assigned(self, ev):
        tid = int(ev["args"]["taskId"])
        # read current meta to get executor and reward
        t = self.taskman.functions.getTask(tid).call()
        # Task struct layout from your contract
        executor = t[9]  # address executor
        reward = t[7]    # uint256 reward
        msg = TaskAssignment(task_id=tid, executor=executor, reward_wei=str(reward))
        self.pub_task_assigned.publish(msg)
        self._bump_cursor(ev)

    def handle_service_registered(self, sid):
        # use getServiceMeta for stable output
        meta = self.servman.functions.getServiceMeta(sid).call()
        # returns: sid, categoryHash, serviceTypeHash, price, creator, active, busy
        m = ServiceMeta(
            id=int(meta[0]),
            category_hash=list(bytearray(self._to_bytes32(meta[1]))),
            service_type_hash=list(bytearray(self._to_bytes32(meta[2]))),
            price_wei=str(meta[3]),
            creator=str(meta[4]),
            active=bool(meta[5]),
            busy=bool(meta[6]),
        )
        self.pub_service_registered.publish(m)

    @staticmethod
    def _to_bytes32(x):
        if isinstance(x, (bytes, bytearray)) and len(x) == 32:
            return bytes(x)
        # web3 may return HexBytes
        try:
            b = bytes(x)
            if len(b) == 32:
                return b
        except Exception:
            pass
        # last resort
        return Web3.to_bytes(hexstr=Web3.to_hex(x)).rjust(32, b"\x00")

    def _bump_cursor(self, ev):
        self.ckpt.update_cursor(int(ev["blockNumber"]), int(ev["logIndex"]))

def main():
    listener = EthEventListener()
    rospy.loginfo("eth_event_listener running, chain id %s", listener.w3.eth.chain_id)
    rospy.spin()

if __name__ == "__main__":
    main()
