#!/usr/bin/env python3
# Placeholder for ABI loading helpers
#!/usr/bin/env python3
import json
import os
import yaml
from web3 import Web3

def _is_connected(w3):
    # works on web3 v5 and v6
    try:
        return w3.is_connected()
    except AttributeError:
        return w3.isConnected()

def load_config():
    """
    Try to read the dao.yaml ROS param first,
    otherwise load the default file from the package.
    """
    try:
        import rospy
        cfg = rospy.get_param("dao_config", None)
        if isinstance(cfg, dict):
            return cfg
    except Exception:
        pass

    # fallback to file on disk
    try:
        import rospkg
        rp = rospkg.RosPack()
        path = os.path.join(rp.get_path("ros_eth_bridge"), "config", "dao.yaml")
    except Exception:
        # last chance, environment variable
        path = os.environ.get("ROS_ETH_DAO_YAML", "")
        if not path:
            raise RuntimeError("dao.yaml not found, set ROS param dao_config or env ROS_ETH_DAO_YAML")

    with open(path, "r") as f:
        return yaml.safe_load(f)

def make_web3(cfg):
    ws = cfg["chain"].get("rpc_url", "")
    http = cfg["chain"].get("http_fallback_url", "")
    w3 = None
    if ws.startswith("ws"):
        try:
            w3 = Web3(Web3.WebsocketProvider(ws, websocket_timeout=30))
        except Exception:
            w3 = None
    if w3 is None and http:
        w3 = Web3(Web3.HTTPProvider(http, request_kwargs={"timeout": 30}))
    if w3 is None or not _is_connected(w3):
        raise RuntimeError("Web3 cannot connect, check rpc_url and http_fallback_url in dao.yaml")
    return w3

def load_contract(w3, address, abi_path):
    # use abi_path exactly as provided in YAML
    with open(abi_path, "r") as f:
        raw = json.load(f)

    # accept common formats
    if isinstance(raw, list):
        abi = raw
    elif isinstance(raw, dict):
        if "abi" in raw and isinstance(raw["abi"], list):
            abi = raw["abi"]                     # Hardhat or Truffle artifact
        elif "output" in raw and isinstance(raw["output"], dict) and isinstance(raw["output"].get("abi"), list):
            abi = raw["output"]["abi"]          # solc combined json
        else:
            raise ValueError(f"ABI list not found in {abi_path}")
    elif isinstance(raw, str):
        parsed = json.loads(raw)
        if isinstance(parsed, list):
            abi = parsed
        else:
            raise ValueError(f"ABI in {abi_path} is a string but not a JSON list")
    else:
        raise ValueError(f"Unsupported ABI format in {abi_path}")

    return w3.eth.contract(address=Web3.to_checksum_address(address), abi=abi)
