#!/usr/bin/env python3
import os, sys
import time
import getpass
import threading
import rospy
import rospkg
import actionlib
from web3 import Web3
from eth_account import Account

# Ensure we import helper modules from the package src folder
pkg_path = rospkg.RosPack().get_path("ros_eth_bridge")
sys.path.insert(0, os.path.join(pkg_path, "src"))

from abi_loader import load_config, make_web3, load_contract
from ros_eth_msgs.msg import (
    RegisterServiceAction, RegisterServiceFeedback, RegisterServiceResult,
    RegisterTaskAction,    RegisterTaskFeedback,    RegisterTaskResult,
    SubmitProofAction, SubmitProofFeedback, SubmitProofResult,
    RemoveTaskAction,      RemoveTaskFeedback,      RemoveTaskResult,
    RemoveServiceAction,   RemoveServiceFeedback,   RemoveServiceResult,
    ActivateServiceAction, ActivateServiceFeedback, ActivateServiceResult,
    ActivateTaskAction, ActivateTaskFeedback, ActivateTaskResult,
    SetServiceBusyAction, SetServiceBusyFeedback, SetServiceBusyResult,
)

class Wallet:
    def __init__(self, cfg):
        self.addr = Web3.to_checksum_address(cfg["wallet"]["address"])
        self.path = os.path.expanduser(cfg["wallet"]["keystore_path"])
        self._key = None

    def unlock(self):
        if self._key:
            return
        with open(self.path, "r") as f:
            ks_text = f.read()

        pw = None
        try:
            if rospy.has_param("~wallet_passphrase"):
                pw = rospy.get_param("~wallet_passphrase")
        except Exception:
            pass
        if pw is None and "ETH_WALLET_PASSPHRASE" in os.environ:
            pw = os.environ["ETH_WALLET_PASSPHRASE"]
        if pw is None:
            import getpass
            pw = getpass.getpass("Wallet passphrase, can be empty: ")

        self._key = Account.decrypt(ks_text, pw)

    @property
    def key(self):
        if not self._key:
            self.unlock()
        return self._key

class TxManager:
    def __init__(self):
        rospy.init_node("eth_tx_manager")

        self.cfg = load_config()
        self.w3  = make_web3(self.cfg)
        self.wallet = Wallet(self.cfg)

        c = self.cfg["contracts"]
        p = self.cfg["abi_paths"]
        self.sman = load_contract(self.w3, c["service_manager"], p["service_manager"])
        self.tman = load_contract(self.w3, c["task_manager"],   p["task_manager"])
        self.iec  = load_contract(self.w3, c["iecoin"],         p["iecoin"])

        tx_cfg = self.cfg.get("transaction", {}) or {}
        self.max_fee      = int(tx_cfg.get("max_fee_per_gas_wei", 0)) or None
        self.max_priority = int(tx_cfg.get("max_priority_fee_per_gas_wei", 0)) or None

        self.as_register_service = actionlib.SimpleActionServer(
            "/dao/register_service_action",
            RegisterServiceAction,
            execute_cb=self.handle_register_service,
            auto_start=False,
        )
        self.as_register_task = actionlib.SimpleActionServer(
            "/dao/register_task_action",
            RegisterTaskAction,
            execute_cb=self.handle_register_task,
            auto_start=False,
        )
        self.as_submit_proof = actionlib.SimpleActionServer(
            "/dao/submit_proof_action",
            SubmitProofAction,
            execute_cb=self.handle_submit_proof,
            auto_start=False,
        )
        
        self.as_remove_task = actionlib.SimpleActionServer(
            "/dao/remove_task_action",
            RemoveTaskAction,
            execute_cb=self.handle_remove_task,
            auto_start=False,
        )


        self.as_remove_service = actionlib.SimpleActionServer(
            "/dao/remove_service_action",
            RemoveServiceAction,
            execute_cb=self.handle_remove_service,
            auto_start=False,
        )


        self.as_activate_service = actionlib.SimpleActionServer(
            "/dao/activate_service_action",
            ActivateServiceAction,
            execute_cb=self.handle_activate_service,
            auto_start=False,
        )

        self.as_activate_task = actionlib.SimpleActionServer(
            "/dao/activate_task_action",
            ActivateTaskAction,
            execute_cb=self.handle_activate_task,
            auto_start=False,
        )

        self.as_set_service_busy = actionlib.SimpleActionServer(
            "/dao/set_service_busy_action",
            SetServiceBusyAction,
            execute_cb=self.handle_set_service_busy,
            auto_start=False,
        )

        self.as_register_service.start()
        self.as_register_task.start()
        self.as_submit_proof.start()
        self.as_remove_task.start()
        self.as_remove_service.start()
        self.as_activate_service.start()
        self.as_activate_task.start()
        self.as_set_service_busy.start()

        rospy.loginfo("eth_tx_manager ready, chain %s, sender %s",
                      self.w3.eth.chain_id, self.wallet.addr)

    def build_common_tx(self):
        sender = self.wallet.addr
        nonce  = self.w3.eth.get_transaction_count(sender)
        tx = {"from": sender, "nonce": nonce, "chainId": self.w3.eth.chain_id}
        if self.max_fee and self.max_priority:
            tx["maxFeePerGas"] = self.max_fee
            tx["maxPriorityFeePerGas"] = self.max_priority
            tx["type"] = 2
        return tx

    def sign_send_wait(self, tx, min_conf, publish_feedback):
        signed = self.w3.eth.account.sign_transaction(tx, self.wallet.key)
        txh = self.w3.eth.send_raw_transaction(signed.raw_transaction)
        hexh = txh.hex()
        rospy.loginfo("registerService tx %s sent, waiting for %d confirmations", hexh, max(1, min_conf))
        publish_feedback(RegisterServiceFeedback(state="pending", tx_hash=hexh, confirmations=0, error=""))

        rcpt = self.w3.eth.wait_for_transaction_receipt(txh, timeout=600)
        block = rcpt.blockNumber
        ok = (rcpt.status == 1)
        # first confirmation log
        if ok:
            rospy.loginfo("tx %s confirmed in block %d", hexh, block)
        else:
            rospy.logwarn("tx %s failed in block %d", hexh, block)
        conf = 1
        while conf < max(1, min_conf) and not rospy.is_shutdown():
            latest = self.w3.eth.block_number
            conf = max(1, int(latest) - int(block) + 1)
            publish_feedback(RegisterServiceFeedback(state="included", tx_hash=hexh, confirmations=conf, error=""))
            if conf >= min_conf:
                break
            time.sleep(1.0)
        ok = (rcpt.status == 1)
        return hexh, block, ok

    # ---------------- register service ----------------

    def handle_register_service(self, goal):
        pubfb = self.as_register_service.publish_feedback
        try:
            self.wallet.unlock()
            price = self.w3.to_wei(int(goal.price), "ether")
            fn = self.sman.functions.registerService(
                goal.name,
                goal.description,
                goal.category,
                goal.service_type,
                price,
                int(goal.provider_type),
            )

            tx = self.build_common_tx()
            gas = fn.estimate_gas({"from": self.wallet.addr})
            tx["gas"] = int(gas * 1.2)
            tx = fn.build_transaction(tx)

            txh, block, ok = self.sign_send_wait(tx, max(1, int(goal.min_confirmations or 1)), pubfb)
            res = RegisterServiceResult(ok=bool(ok), tx_hash=txh, block_number=int(block))
            if ok:
                self.as_register_service.set_succeeded(res)
            else:
                self.as_register_service.set_aborted(res, "tx reverted")
        except Exception as e:
            pubfb(RegisterServiceFeedback(state="failed", tx_hash="", confirmations=0, error=str(e)))
            res = RegisterServiceResult(ok=False, tx_hash="", block_number=0)
            self.as_register_service.set_aborted(res, str(e))

    # ---------------- register task with auto approval ----------------

    def handle_register_task(self, goal):
        print("entered in the callback")
        pubfb = self.as_register_task.publish_feedback
        try:
            print("Inside try")
            self.wallet.unlock()
            reward = self.w3.to_wei(int(goal.reward), "ether")
            spender = Web3.to_checksum_address(self.cfg["contracts"]["task_manager"])

            # ensure allowance
            current = self.iec.functions.allowance(self.wallet.addr, spender).call()
            if current < reward:
                rospy.loginfo("approving TaskManager for %s wei, current %s", reward, current)
                fn_ap = self.iec.functions.approve(spender, reward)
                tx_ap = self.build_common_tx()
                gas_ap = fn_ap.estimate_gas({"from": self.wallet.addr})
                tx_ap["gas"] = int(gas_ap * 1.2)
                tx_ap = fn_ap.build_transaction(tx_ap)

                txh_ap, block_ap, ok_ap = self.sign_send_wait(
                    tx_ap, max(1, int(goal.min_confirmations or 1)), pubfb
                )
                if not ok_ap:
                    res = RegisterTaskResult(ok=False, tx_hash=txh_ap, block_number=int(block_ap))
                    self.as_register_task.set_aborted(res, "approve reverted")
                    return
                # small confirmation log
                rospy.loginfo("approve included, tx %s", txh_ap)

            # register task
            fn = self.tman.functions.registerTask(
                goal.description,
                goal.category,
                goal.task_type,
                reward,
            )
            tx = self.build_common_tx()
            gas = fn.estimate_gas({"from": self.wallet.addr})
            tx["gas"] = int(gas * 1.2)
            tx = fn.build_transaction(tx)

            txh, block, ok = self.sign_send_wait(tx, max(1, int(goal.min_confirmations or 1)), pubfb)
            res = RegisterTaskResult(ok=bool(ok), tx_hash=txh, block_number=int(block))
            if ok:
                self.as_register_task.set_succeeded(res)
            else:
                self.as_register_task.set_aborted(res, "tx reverted")

        except Exception as e:
            res = RegisterTaskResult(ok=False, tx_hash="", block_number=0)
            self.as_register_task.set_aborted(res, str(e))

    def handle_submit_proof(self, goal):
        print("entered submit_proof callback")
        pubfb = self.as_submit_proof.publish_feedback
        try:
            self.wallet.unlock()

            # build tx
            fn = self.tman.functions.submitProof(int(goal.task_id), goal.proof_uri)
            tx = self.build_common_tx()
            gas = fn.estimate_gas({"from": self.wallet.addr})
            tx["gas"] = int(gas * 1.2)
            tx = fn.build_transaction(tx)

            # send and wait
            txh, block, ok = self.sign_send_wait(tx, max(1, int(goal.min_confirmations or 1)), pubfb)

            # finish
            res = SubmitProofResult(ok=bool(ok), tx_hash=txh, block_number=int(block))
            if ok:
                self.as_submit_proof.set_succeeded(res)
            else:
                self.as_submit_proof.set_aborted(res, "tx reverted")

        except Exception as e:
            res = SubmitProofResult(ok=False, tx_hash="", block_number=0)
            self.as_submit_proof.set_aborted(res, str(e))

    def handle_remove_task(self, goal):
        pubfb = self.as_remove_task.publish_feedback
        try:
            self.wallet.unlock()

            fn = self.tman.functions.removeTask(int(goal.task_id))
            tx = self.build_common_tx()
            gas = fn.estimate_gas({"from": self.wallet.addr})
            tx["gas"] = int(gas * 1.2)
            tx = fn.build_transaction(tx)

            txh, block, ok = self.sign_send_wait(
                tx, max(1, int(goal.min_confirmations or 1)), pubfb
            )
            res = RemoveTaskResult(ok=bool(ok), tx_hash=txh, block_number=int(block))
            if ok:
                self.as_remove_task.set_succeeded(res)
            else:
                self.as_remove_task.set_aborted(res, "tx reverted")
        except Exception as e:
            res = RemoveTaskResult(ok=False, tx_hash="", block_number=0)
            self.as_remove_task.set_aborted(res, str(e))

    def handle_remove_service(self, goal):
        pubfb = self.as_remove_service.publish_feedback
        try:
            self.wallet.unlock()

            fn = self.sman.functions.removeService(int(goal.service_id))
            tx = self.build_common_tx()
            gas = fn.estimate_gas({"from": self.wallet.addr})
            tx["gas"] = int(gas * 1.2)
            tx = fn.build_transaction(tx)

            txh, block, ok = self.sign_send_wait(
                tx, max(1, int(goal.min_confirmations or 1)), pubfb
            )
            res = RemoveServiceResult(ok=bool(ok), tx_hash=txh, block_number=int(block))
            if ok:
                self.as_remove_service.set_succeeded(res)
            else:
                self.as_remove_service.set_aborted(res, "tx reverted")
        except Exception as e:
            res = RemoveServiceResult(ok=False, tx_hash="", block_number=0)
            self.as_remove_service.set_aborted(res, str(e))

    def handle_activate_service(self, goal):
        pubfb = self.as_activate_service.publish_feedback
        try:
            self.wallet.unlock()

            fn = self.sman.functions.activateService(int(goal.service_id))
            tx = self.build_common_tx()
            gas = fn.estimate_gas({"from": self.wallet.addr})
            tx["gas"] = int(gas * 1.2)
            tx = fn.build_transaction(tx)

            txh, block, ok = self.sign_send_wait(
                tx, max(1, int(goal.min_confirmations or 1)), pubfb
            )
            res = ActivateServiceResult(ok=bool(ok), tx_hash=txh, block_number=int(block))
            if ok:
                self.as_activate_service.set_succeeded(res)
            else:
                self.as_activate_service.set_aborted(res, "tx reverted")
        except Exception as e:
            res = ActivateServiceResult(ok=False, tx_hash="", block_number=0)
            self.as_activate_service.set_aborted(res, str(e))

    def handle_activate_task(self, goal):
        pubfb = self.as_activate_task.publish_feedback
        try:
            self.wallet.unlock()

            fn = self.tman.functions.activateTask(int(goal.task_id))
            tx = self.build_common_tx()
            gas = fn.estimate_gas({"from": self.wallet.addr})
            tx["gas"] = int(gas * 1.2)
            tx = fn.build_transaction(tx)

            txh, block, ok = self.sign_send_wait(
                tx, max(1, int(goal.min_confirmations or 1)), pubfb
            )
            res = ActivateTaskResult(ok=bool(ok), tx_hash=txh, block_number=int(block))
            if ok:
                self.as_activate_task.set_succeeded(res)
            else:
                self.as_activate_task.set_aborted(res, "tx reverted")
        except Exception as e:
            res = ActivateTaskResult(ok=False, tx_hash="", block_number=0)
            self.as_activate_task.set_aborted(res, str(e))

    def handle_set_service_busy(self, goal):
    # note: only the service creator or the Organization can call setBusy in your contract
    # the service must be active
        try:
            self.wallet.unlock()

            svc_id = int(goal.service_id)
            busy   = bool(goal.is_busy)

            fn = self.sman.functions.setBusy(svc_id, busy)
            tx = self.build_common_tx()
            gas = fn.estimate_gas({"from": self.wallet.addr})
            tx["gas"] = int(gas * 1.2)
            tx = fn.build_transaction(tx)

            # pass a no op feedback publisher to keep your existing sign_send_wait unchanged
            noop_fb = lambda _msg: None
            txh, block, ok = self.sign_send_wait(tx, max(1, int(goal.min_confirmations or 1)), noop_fb)

            res = SetServiceBusyResult(ok=bool(ok), tx_hash=txh, block_number=int(block))
            if ok:
                self.as_set_service_busy.set_succeeded(res)
            else:
                self.as_set_service_busy.set_aborted(res, "tx reverted")
        except Exception as e:
            res = SetServiceBusyResult(ok=False, tx_hash="", block_number=0)
            self.as_set_service_busy.set_aborted(res, str(e))



def main():
    TxManager()
    rospy.loginfo("eth_tx_manager running")
    rospy.spin()

if __name__ == "__main__":
    main()
